# -*- coding: utf-8 -*-
"""CLI модули."""
