# -*- coding: utf-8 -*-
"""Core модули."""
