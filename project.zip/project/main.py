#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║    ███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗                             ║
║    ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗                              ║
║    ██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║                              ║
║    ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║                              ║
║    ██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝                              ║
║    ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝                               ║
║                                                                              ║
║                    NEURO COMMENT BOT — Premium Edition                       ║
║                              Version 3.0.0                                   ║
║                                                                              ║
║          Telegram Neuro Commenting System with Web Interface                 ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import asyncio
import webbrowser
import threading
import time

# Устанавливаем UTF-8 для Windows
if sys.platform == "win32":
    os.system("chcp 65001 >nul 2>&1")
    
    # Включаем ANSI цвета в Windows
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except:
        pass

# Версия
__version__ = "3.0.0"

# Директории проекта
PROJECT_DIRS = [
    "каналы",
    "tdata_комменты",
    "sessions_комменты",
    "прокси_комменты",
    "каналы_прогрев",
    "чаты_прогрев",
    "tdata_прогрев",
    "sessions_прогрев",
    "прокси_прогрев",
    "logs",
    "data",
    "web/templates",
]


def print_banner():
    """Показать баннер"""
    banner = """
\033[38;5;135m╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║    \033[38;5;141m███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗ \033[38;5;135m                               ║
║    \033[38;5;141m████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗\033[38;5;135m                              ║
║    \033[38;5;147m██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║\033[38;5;135m                              ║
║    \033[38;5;147m██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║\033[38;5;135m                              ║
║    \033[38;5;153m██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝\033[38;5;135m                              ║
║    \033[38;5;153m╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ \033[38;5;135m                              ║
║                                                                              ║
║              \033[38;5;255m🤖 NEURO COMMENT BOT — Premium Edition\033[38;5;135m                          ║
║                         \033[38;5;245mVersion 3.0.0\033[38;5;135m                                        ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝\033[0m
"""
    print(banner)


def create_directories():
    """Создать необходимые директории"""
    base_path = os.path.dirname(os.path.abspath(__file__))
    
    for dir_name in PROJECT_DIRS:
        dir_path = os.path.join(base_path, dir_name)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
            print(f"  \033[38;5;245m├─\033[0m 📁 Создана папка: {dir_name}")


def check_requirements():
    """Проверить зависимости"""
    required = ["fastapi", "uvicorn", "aiofiles", "aiosqlite", "telethon", "openai"]
    missing = []
    
    for package in required:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"\n\033[38;5;196m❌ Не установлены пакеты: {', '.join(missing)}\033[0m")
        print(f"\033[38;5;245m   Установите: pip install {' '.join(missing)}\033[0m\n")
        return False
    
    return True


def open_browser(port: int):
    """Открыть браузер с задержкой"""
    time.sleep(2)  # Ждём запуска сервера
    url = f"http://localhost:{port}"
    print(f"\n  \033[38;5;82m🌐 Открываю браузер: {url}\033[0m\n")
    webbrowser.open(url)


async def run_web_server(port: int = 8080):
    """Запустить веб-сервер"""
    from web.server import app
    import uvicorn
    
    config = uvicorn.Config(
        app,
        host="0.0.0.0",
        port=port,
        log_level="warning",
        access_log=False
    )
    server = uvicorn.Server(config)
    await server.serve()


async def initialize():
    """Инициализация системы"""
    print("\n  \033[38;5;245m⏳ Инициализация системы...\033[0m\n")
    
    # Создаём директории
    create_directories()
    
    # Инициализируем базу данных
    try:
        from core.database import db
        await db.init()
        print("  \033[38;5;82m✓\033[0m База данных готова")
    except Exception as e:
        print(f"  \033[38;5;196m✗\033[0m Ошибка базы данных: {e}")
    
    # Загружаем конфигурацию
    try:
        from core.state import state
        state.load_config()
        print("  \033[38;5;82m✓\033[0m Конфигурация загружена")
    except Exception as e:
        print(f"  \033[38;5;196m✗\033[0m Ошибка конфигурации: {e}")
    
    # Настраиваем логгеры
    try:
        from core.logger import setup_logging
        setup_logging()
        print("  \033[38;5;82m✓\033[0m Логирование настроено")
    except Exception as e:
        print(f"  \033[38;5;196m✗\033[0m Ошибка логирования: {e}")
    
    print("\n  \033[38;5;82m🚀 Система готова к работе!\033[0m\n")


async def main():
    """Главная функция"""
    print_banner()
    
    # Проверяем зависимости
    if not check_requirements():
        return
    
    # Инициализация
    await initialize()
    
    # Определяем порт
    port = 8080
    
    # Запускаем открытие браузера в отдельном потоке
    browser_thread = threading.Thread(target=open_browser, args=(port,), daemon=True)
    browser_thread.start()
    
    # Запускаем веб-сервер
    print(f"  \033[38;5;135m╔{'═' * 68}╗\033[0m")
    print(f"  \033[38;5;135m║\033[0m  🌐 Веб-интерфейс запущен: \033[38;5;82mhttp://localhost:{port}\033[0m                      \033[38;5;135m║\033[0m")
    print(f"  \033[38;5;135m║\033[0m  📱 Для доступа с телефона: http://<IP компьютера>:{port}              \033[38;5;135m║\033[0m")
    print(f"  \033[38;5;135m║\033[0m  🛑 Для остановки нажмите: \033[38;5;196mCtrl+C\033[0m                                   \033[38;5;135m║\033[0m")
    print(f"  \033[38;5;135m╚{'═' * 68}╝\033[0m\n")
    
    try:
        await run_web_server(port)
    except KeyboardInterrupt:
        print("\n\n  \033[38;5;226m⚠️  Получен сигнал остановки...\033[0m")
        
        # Останавливаем сервисы
        try:
            from core.scheduler import scheduler
            await scheduler.stop_all()
            print("  \033[38;5;82m✓\033[0m Сервисы остановлены")
        except:
            pass
        
        print("  \033[38;5;82m✓\033[0m До свидания!\n")


def run_cli():
    """Запустить в режиме CLI (без веба)"""
    print_banner()
    
    async def cli_main():
        await initialize()
        from cli.menu import menu
        await menu.run()
    
    try:
        asyncio.run(cli_main())
    except KeyboardInterrupt:
        print("\n\n  До свидания!\n")


if __name__ == "__main__":
    # Проверяем аргументы
    if len(sys.argv) > 1:
        if sys.argv[1] == "--cli":
            run_cli()
        elif sys.argv[1] == "--help":
            print("""
NEURO COMMENT BOT — Premium Edition

Использование:
    python main.py          Запуск с веб-интерфейсом (по умолчанию)
    python main.py --cli    Запуск в режиме консоли
    python main.py --help   Показать эту справку

Веб-интерфейс:
    После запуска откроется браузер на http://localhost:8080
    Управляйте всем через красивый веб-интерфейс!

Режим CLI:
    Консольное меню для управления без браузера.
""")
        else:
            print(f"Неизвестный аргумент: {sys.argv[1]}")
            print("Используйте --help для справки")
    else:
        # По умолчанию — веб-интерфейс
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            print("\n\n  До свидания!\n")
